from pyspark.sql import SparkSession
from utilities import titanic

if __name__ == '__main__': 
    spark = SparkSession.builder.appName('PySpark-App').getOrCreate() 
    print('Session created') 
    
    input_path = '/home/awantik/workspace/AI102-MachineLearning/data/titanic-train.csv.txt'
    output_path = '/home/awantik/workspace/out'
    titanic = titanic.Titanic(spark, input_path, output_path)

    titanic.load()
    titanic.clean()

    titanic.create_preprocessors()
    titanic.dimensionaity_reduction()
    titanic.create_estimators()
    titanic.create_pipeline()

    train,test = titanic.split_data()

    titanic.fit(train)
    out_df = titanic.predict(test)
    out_df.write.json(output_path)
    


