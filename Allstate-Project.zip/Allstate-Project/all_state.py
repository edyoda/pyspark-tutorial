import argparse

from utilities.mlfunc import process


#

# Simple and silly solution for the "Allstate Claims Severity" competition on Kaggle

# Competition page: https://www.kaggle.com/c/allstate-claims-severity

#


if __name__ == "__main__":

    parser = argparse.ArgumentParser()


    parser.add_argument("--trainInput",  help="Path to file/directory for training data", required=True)

    parser.add_argument("--testInput",   help="Path to file/directory for test data", required=True)

    parser.add_argument("--outputFile",  help="Path to output file")

    parser.add_argument("--algoNumTrees", nargs='+', type=int, help="One or more options for number of trees for RandomForest model. Default: 3", default=[3])

    parser.add_argument("--algoMaxDepth", nargs='+', type=int, help="One or more values for depth limit. Default: 4", default=[4])

    parser.add_argument("--algoMaxBins",  nargs='+', type=int, help="One or more values for max bins for RandomForest model. Default: 32", default=[32])

    parser.add_argument("--numFolds",    type=int,   help="Number of folds for K-fold Cross Validation. Default: 10", default=10)

    parser.add_argument("--trainSample", type=float, help="Sample fraction from 0.0 to 1.0 for train data", default=1.0)

    parser.add_argument("--testSample",  type=float, help="Sample fraction from 0.0 to 1.0 for test data", default=1.0)



    params = parser.parse_args()



    process(params)